# ?? MistEngine v0.3.0-prealpha - Windows Release 
 
## ?? Quick Start 
 
1. **Run the game**: Double-click `bin\Start-MistEngine.bat` 
2. **Start FPS game**: Press `F3` in the engine 
3. **Setup AI**: Press `F2` for AI assistant setup (optional) 
 
## ?? Controls 
 
- **WASD**: Move player 
- **Mouse**: Look around 
- **Left Click**: Shoot 
- **1-4**: Switch weapons 
- **ESC**: Pause game 
- **F1**: Toggle wireframe 
- **F2**: AI assistant 
- **F3**: Start/stop FPS game 
 
## ?? Features 
 
- Complete FPS game with intelligent enemies 
- Multiple weapon types (Pistol, Rifle, Shotgun, Sniper) 
- AI-powered development assistant 
- Modern ECS architecture 
- Professional game engine with editor 
 
## ?? Requirements 
 
- Windows 10/11 (64-bit) 
- OpenGL 3.3 compatible graphics card 
- 4GB RAM recommended 
 
For full documentation, see the `docs\` folder. 
