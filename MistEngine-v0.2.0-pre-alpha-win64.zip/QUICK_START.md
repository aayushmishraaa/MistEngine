﻿# MistEngine Pre-Alpha - Quick Start

## Running the Engine
1. Run Launch_MistEngine.bat or
2. Navigate to in/ folder and run MistEngine.exe

## AI Assistant Setup (Optional)
1. Copy i_config.example.json to i_config.json
2. Get API key from: https://aistudio.google.com/app/apikey
3. Edit i_config.json and add your key
4. In engine: AI Menu > Configure API Key

## Controls
- WASD: Move camera
- Mouse: Look around
- F2: Open AI assistant
- Right-click: Context menus

## Creating Objects
- GameObject Menu > 3D Object > Cube/Sphere/Plane
- Use Hierarchy window to manage objects
- Use Inspector to edit properties

## Documentation
See docs/ folder for complete documentation

## Support
- GitHub: https://github.com/yourusername/MistEngine
- Issues: Report bugs on GitHub Issues
- AI Help: Press F2 in the engine

**Status: Pre-Alpha** - Expect bugs and missing features!
