﻿# MistEngine Modules

## What are Modules?
Modules are DLL files that extend MistEngine's functionality without modifying the core engine.

## How to Add Modules
1. Download a .dll module file
2. Copy it to this modules/ folder  
3. Restart MistEngine
4. Module will be automatically loaded!

## Current Modules
- ExampleModule.dll - Example module demonstrating the module system## Module Development
To create your own modules:
1. Use the MistEngine module interface (see ModuleManager.h)
2. Build as a DLL with exported CreateModule/DestroyModule functions
3. Copy the DLL to this folder
4. Restart MistEngine

## Troubleshooting
- Ensure modules are built for x64 platform
- Check console output for loading errors
- Verify module interface version compatibility (currently v1)
- Make sure dependencies are available

## Module Types Supported
- Component modules (add new ECS components)
- System modules (add new ECS systems)  
- Renderer extensions (add new rendering features)
- Tool modules (add new editor tools)
- Script modules (add scripting support)

For detailed module development guides, see the MistEngine documentation.
